USE master;
GO

IF DATABASEPROPERTYEX ('SelectCount', 'Version') > 0
	DROP DATABASE SelectCount;
GO

-- Create the database
CREATE DATABASE SelectCount;
GO

USE SelectCount;
GO
SET NOCOUNT ON;
GO

-- Create the test table
CREATE TABLE Test (
	c1 INT IDENTITY,
	c2 BIGINT DEFAULT 1,
	c3 CHAR (1000) DEFAULT 'a');
GO
INSERT INTO Test DEFAULT VALUES;
GO 10000 

-- Enable including actual query plan

-- First select and look at plan
SELECT COUNT (*) FROM Test;
GO

-- Create a nonclustered index
CREATE NONCLUSTERED INDEX
	Test_NC1 ON Test (c2);
GO 

-- Second select and look at plan
SELECT COUNT (*) FROM Test;
GO

-- Create smaller nonclustered index
CREATE NONCLUSTERED INDEX
	Test_NC2 ON Test (c1);
GO 

-- Third select and look at plan
SELECT COUNT (*) FROM Test;
GO

-- How big are the structures?
SELECT
	[index_id],
	[page_count]
FROM
	sys.dm_db_index_physical_stats (
		DB_ID (), OBJECT_ID ('Test'), NULL, NULL, 'LIMITED');
GO 

