USE master;
GO

IF DATABASEPROPERTYEX ('RecordLocation', 'Version') > 0
	DROP DATABASE RecordLocation;
GO

-- Create the database
CREATE DATABASE RecordLocation;
GO

USE RecordLocation;
GO
SET NOCOUNT ON;
GO

-- Create the test table
CREATE TABLE Test (
	c1 INT IDENTITY,
	c2 BIGINT DEFAULT 1,
	c3 CHAR (1000) DEFAULT 'a');
GO
INSERT INTO Test DEFAULT VALUES;
GO 1000 

-- Why might we care about record location?
--		- investigating corruption
--		- investigating fragmentation
--		- correlating latch waits to poor I/O

-- Get the physical locations
SELECT
	*,
	%%PHYSLOC%%
FROM
	Test;
GO

-- Not very human-readable...
SELECT
	t.*,
	plc.*
FROM
	Test t
CROSS APPLY fn_PhysLocCracker (%%PHYSLOC%%) plc;
GO
