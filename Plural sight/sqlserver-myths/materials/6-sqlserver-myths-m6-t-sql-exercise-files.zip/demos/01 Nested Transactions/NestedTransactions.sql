USE master;
GO
IF DATABASEPROPERTYEX ('NestedTransactions', 'Version') > 0
	DROP DATABASE NestedTransactions;
GO

CREATE DATABASE NestedTransactions;
GO

USE NestedTransactions;
GO
CREATE TABLE Test (
	c1 INT,
	c2 VARCHAR (4000));
GO

-- Outer transaction
BEGIN TRAN

INSERT INTO test VALUES (1, REPLICATE ('Susy', 1000));
INSERT INTO test VALUES (2, REPLICATE ('John', 1000));
GO

SELECT @@TRANCOUNT;
GO

-- Look at usage

-- Start nested xact
BEGIN TRAN

INSERT INTO test VALUES (3, REPLICATE ('Dave', 1000));
INSERT INTO test VALUES (4, REPLICATE ('Bret', 1000));
GO

SELECT @@TRANCOUNT;
GO

-- Look at usage

-- Commit next transaction
COMMIT TRAN;
GO

SELECT @@TRANCOUNT;
GO

-- Look at usage
-- Any change?

-- Do final commit
COMMIT TRAN;
GO

SELECT @@TRANCOUNT;
GO

-- Look at usage

