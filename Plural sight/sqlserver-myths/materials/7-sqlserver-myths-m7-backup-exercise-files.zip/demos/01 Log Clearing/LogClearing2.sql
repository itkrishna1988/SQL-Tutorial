USE master;
GO

SET NOCOUNT ON;
GO

-- Start the long-running transaction
BEGIN TRAN;
GO

INSERT INTO LogClearing.dbo.Test DEFAULT VALUES;
GO 1000

-- Now switch-back...

COMMIT TRAN;
GO

