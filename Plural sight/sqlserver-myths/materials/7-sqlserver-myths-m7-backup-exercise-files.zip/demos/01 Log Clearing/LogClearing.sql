USE master;
GO

IF DATABASEPROPERTYEX ('LogClearing', 'Version') > 0
	DROP DATABASE LogClearing;
GO

-- Create the database
CREATE DATABASE LogClearing;
GO

USE LogClearing;
GO

-- Create a table and insert 8MB
CREATE TABLE Test (
	c1 INT IDENTITY,
	c2 CHAR (8000) DEFAULT 'a');
GO
CREATE CLUSTERED INDEX Test_CL ON Test (c1);
GO

SET NOCOUNT ON;
GO

INSERT INTO Test DEFAULT VALUES;
GO 1000

-- Put the database into the FULL recovery
-- model and clear out the log.
ALTER DATABASE LogClearing SET RECOVERY FULL;
GO

BACKUP DATABASE LogClearing TO
	DISK = 'D:\PluralSight\LogClearing_Full_0.bak'
	WITH INIT, STATS;
GO

BACKUP LOG LogClearing TO
	DISK = 'D:\PluralSight\LogClearing_Log_0_Initial.bak'
	WITH INIT, STATS;
GO

-- Now rebuild the clustered index to
-- generate a bunch of log
ALTER INDEX Test_CL ON Test REBUILD;
GO

-- Backup the log to get a baseline size
BACKUP LOG LogClearing TO
	DISK = 'D:\PluralSight\LogClearing_Log_1_Baseline.bak'
	WITH INIT, STATS;
GO

-- Test 1
-- Now rebuild the clustered index again
-- to generate more log
ALTER INDEX Test_CL ON Test REBUILD;
GO

-- Now try a full backup and see if it clears
-- the log
BACKUP DATABASE LogClearing TO
	DISK = 'D:\PluralSight\LogClearing_Full_1.bak'
	WITH INIT, STATS;
GO

-- If it did, this next log backup should be
-- very small
BACKUP LOG LogClearing TO
	DISK = 'D:\PluralSight\LogClearing_Log_2_FullTest.bak'
	WITH INIT, STATS;
GO

-- Test 2
-- Now rebuild the clustered index again
-- to generate more log
ALTER INDEX Test_CL ON Test REBUILD;
GO

-- Now try a checkpoint and see if it clears
-- the log
CHECKPOINT;
GO

-- If it did, this next log backup should be
-- very small
BACKUP LOG LogClearing TO
	DISK = 'D:\PluralSight\LogClearing_Log_3_CheckTest.bak'
	WITH INIT, STATS;
GO

-- Test 4
-- Now the case where there's a long-running
-- transaction and the log can't be cleared
-- by the backup. When does it get cleared?

-- In the other window, do a long-running
-- transaction...

-- In the other window, try a log backup

-- How much log is being used?
DBCC SQLPERF (LOGSPACE);
GO

-- Now let's take a log backup
BACKUP LOG LogClearing TO
	DISK = 'D:\PluralSight\LogClearing_Log_4_LongTest.bak'
	WITH INIT, STATS;
GO

-- How big is it?

-- Did the percentage used go down?
DBCC SQLPERF (LOGSPACE);
GO

-- Now commit the transaction...

-- Did the percentage used go down?
DBCC SQLPERF (LOGSPACE);
GO

-- Yes, why? Log reservation.

-- How about a checkpoint?
CHECKPOINT;
GO
DBCC SQLPERF (LOGSPACE);
GO

-- How about a full backup?
BACKUP DATABASE LogClearing TO
	DISK = 'D:\PluralSight\LogClearing_Full_2.bak'
	WITH INIT, STATS;
GO
DBCC SQLPERF (LOGSPACE);
GO

-- How about a log backup?
BACKUP LOG LogClearing TO
	DISK = 'D:\PluralSight\LogClearing_Log_LongTest2.bak'
	WITH INIT, STATS;
GO
DBCC SQLPERF (LOGSPACE);
GO
