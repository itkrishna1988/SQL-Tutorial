USE master;
GO

IF DATABASEPROPERTYEX ('LogBackupChain', 'Version') > 0
	DROP DATABASE LogBackupChain;
GO

-- Create the database
CREATE DATABASE LogBackupChain;
GO

USE LogBackupChain;
GO

-- Create a table and insert 8MB
CREATE TABLE BigTable (
	c1 INT IDENTITY,
	c2 CHAR (8000) DEFAULT 'a');
GO

-- Put the database into the FULL recovery.
ALTER DATABASE LogBackupChain SET RECOVERY FULL;
GO

-- Initial backup
BACKUP DATABASE LogBackupChain TO
	DISK = 'D:\PluralSight\LogBackupChain.bak'
	WITH INIT, STATS;
GO

SET NOCOUNT ON;
GO

INSERT INTO BigTable DEFAULT VALUES;
GO 100

-- Log backup
BACKUP LOG LogBackupChain TO
	DISK = 'D:\PluralSight\LogBackupChain_Log1.bak'
	WITH INIT, STATS;
GO

-- Now switch to SIMPLE, do some stuff, and switch back
ALTER DATABASE LogBackupChain SET RECOVERY SIMPLE;
GO

INSERT INTO BigTable DEFAULT VALUES;
GO 100

CHECKPOINT;
GO

ALTER DATABASE LogBackupChain SET RECOVERY FULL;
GO

-- Now try a log backup
BACKUP LOG LogBackupChain TO
	DISK = 'D:\PluralSight\LogBackupChain_Log2.bak'
	WITH INIT, STATS;
GO

-- Look at recovery status
SELECT * FROM sys.database_recovery_status
WHERE [database_id] = DB_ID ('LogBackupChain');
GO

-- Restart log backup chain
BACKUP DATABASE LogBackupChain TO
	DISK = 'D:\PluralSight\LogBackupChain_Diff.bak'
	WITH DIFFERENTIAL, INIT, STATS;
GO

-- Look at recovery status
SELECT * FROM sys.database_recovery_status
WHERE [database_id] = DB_ID ('LogBackupChain');
GO

-- Now try the log backup again
BACKUP LOG LogBackupChain TO
	DISK = 'D:\PluralSight\LogBackupChain_Log2.bak'
	WITH INIT, STATS;
GO