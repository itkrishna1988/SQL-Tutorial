/*
Download the SalesDB database zip file, unzip it and restore it.
Get it from: https://s3.amazonaws.com/pluralsight-mediasource/sqlskills/SalesDBOriginal.zip

Here's an example of restoring it:

RESTORE DATABASE SalesDB
	FROM DISK = N'D:\PluralSight\SalesDBOriginal.bak'
	WITH MOVE N'SalesDBData' TO N'D:\PluralSight\SalesDBData.mdf',
	MOVE N'SalesDBLog' TO N'D:\PluralSight\SalesDBLog.ldf',
	REPLACE, STATS = 10;
GO
*/

USE msdb
GO

IF  EXISTS (SELECT * FROM sys.objects
	WHERE [object_id] = OBJECT_ID(N'[dbo].[MyStoredProc]'))
	DROP PROCEDURE [dbo].[MyStoredProc]
GO

CREATE PROCEDURE MyStoredProc
AS
BEGIN

-- Pre-aggregate data into tempdb
SELECT * INTO #TempCustomers
FROM SalesDB..Customers;

CREATE NONCLUSTERED INDEX #TC_CustomerID
ON #TempCustomers (CustomerID);

SELECT * INTO #TempProducts
FROM SalesDB..Products;

CREATE NONCLUSTERED INDEX #TP_ProductID
ON #TempProducts (ProductID);
CREATE NONCLUSTERED INDEX #TP_Price
ON #TempProducts (Price);

SELECT * INTO #TempSales
FROM SalesDB..Sales;

CREATE NONCLUSTERED INDEX #TS_SalesID
ON #TempSales (SalesID);
CREATE NONCLUSTERED INDEX #TS_CustomerID
ON #TempSales (CustomerID);
CREATE NONCLUSTERED INDEX #TS_ProductID
ON #TempSales (ProductID);

SELECT
	tp.Name AS [Product],
	SUM (ts.Quantity) AS [Quantity],
	tp.Price AS [Amount]
FROM #TempProducts AS tp
JOIN #TempSales AS ts
	ON ts.ProductID = tp.ProductID
GROUP BY tp.Name, tp.Price
ORDER BY tp.Name;
END
GO

