-- Turn on capturing plan

-- With default code
EXEC msdb..MyStoredProc;
GO

-- What did the plan look like?

-- Remove some wasted nonclustereds
EXEC msdb..MyStoredProc;
GO

-- What did the plan look like?

-- Remove temp tables
EXEC msdb..MyStoredProc;
GO