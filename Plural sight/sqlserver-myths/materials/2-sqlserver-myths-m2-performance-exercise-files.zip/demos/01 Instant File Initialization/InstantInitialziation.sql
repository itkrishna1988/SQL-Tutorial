-- Empty the error log
EXEC sp_cycle_errorlog;
GO

-- Enable trace flags
DBCC TRACEON (3605, 3004, -1);
GO

-- Show zero initialization happening
CREATE DATABASE dummy;
GO

EXEC xp_readerrorlog;
GO

DROP DATABASE dummy;
GO

-- Enable instant initalization and bounce instance

-- Reenable trace flags and clear error log
EXEC sp_cycle_errorlog;
GO

DBCC TRACEON (3605, 3004, -1);
GO

-- Show instant initialization happening
CREATE DATABASE dummy;
GO

EXEC xp_readerrorlog;
GO

DROP DATABASE dummy;
GO