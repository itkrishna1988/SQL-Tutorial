USE master;
GO

IF DATABASEPROPERTYEX ('KeyUpdateTest', 'Version') > 0
	DROP DATABASE KeyUpdateTest;
GO

CREATE DATABASE KeyUpdateTest;
GO

USE KeyUpdateTest;
GO
CREATE TABLE test (
	c1 INT,
	c2 VARCHAR (2000));
GO
CREATE CLUSTERED INDEX test_cl ON test (c1);
GO
INSERT INTO test VALUES (1, REPLICATE ('Paul', 500));
GO

-- Now do an update of the 4 byte key
BEGIN TRAN
GO
UPDATE test SET c1 = 2 WHERE c1 =1;
GO 

-- How much space is being used?
SELECT [database_transaction_log_bytes_used]
FROM sys.dm_tran_database_transactions
WHERE [database_id] = DB_ID ('KeyUpdateTest');
GO 

COMMIT TRAN;
GO

-- How about this case?
DROP TABLE test;
GO

CREATE TABLE test (
	c1 INT,
	c2 VARCHAR (4000));
GO
CREATE CLUSTERED INDEX test_cl ON test (c1);
GO

INSERT INTO test VALUES (1, REPLICATE ('Paul', 1000));
GO
INSERT INTO test VALUES (2, REPLICATE ('Andy', 1000));
GO

BEGIN TRAN
GO
UPDATE test SET c1 = 3 WHERE c1 =1;
GO 

-- How much log space in this case?
SELECT [database_transaction_log_bytes_used]
FROM sys.dm_tran_database_transactions
WHERE [database_id] = DB_ID ('KeyUpdateTest');
GO 

COMMIT TRAN;
GO
