IF DATABASEPROPERTYEX ('TailLog', 'Version') > 0
	DROP DATABASE TailLog;
GO

-- Create the database
CREATE DATABASE TailLog ON PRIMARY (
    NAME = 'TailLog_data',
    FILENAME = N'D:\PluralSight\TailLog_data.mdf')
LOG ON (
    NAME = 'TailLog_log',
    FILENAME = N'D:\PluralSight\TailLog_log.ldf',
    SIZE = 5MB,
    FILEGROWTH = 1MB);
GO

-- Create a table
CREATE TABLE TailLog..TestTable (
	c1 INT IDENTITY,
	c2 VARCHAR (100));
GO

INSERT INTO TailLog..TestTable
	VALUES ('Initial data: transaction 1');
GO

-- And take a full backup
BACKUP DATABASE TailLog TO
	DISK = 'D:\PluralSight\TailLog.bck'
WITH INIT;
GO

-- Now add some more data
INSERT INTO TailLog..TestTable
	VALUES ('Transaction 2');
GO
INSERT INTO TailLog..TestTable
	VALUES ('Transaction 3');
GO

-- Simulate a crash
SHUTDOWN WITH NOWAIT;
GO

-- Trash the data file and restart SQL

USE TailLog;
GO

-- The backup doesn't have the most recent
-- transactions - if we restore it we'll
-- lose them.

-- Take a log backup?
BACKUP LOG TailLog TO
	DISK = 'D:\PluralSight\TailLog_tail.bck'
WITH INIT;
GO

-- Use the special syntax!
BACKUP LOG TailLog TO
	DISK = 'D:\PluralSight\TailLog_tail.bck'
WITH INIT, NO_TRUNCATE;
GO

-- Now restore
RESTORE DATABASE TailLog FROM
	DISK = 'D:\PluralSight\TailLog.bck'
WITH REPLACE, NORECOVERY;
GO

RESTORE LOG TailLog FROM
	DISK = 'D:\PluralSight\TailLog_tail.bck'
WITH NORECOVERY;
GO

RESTORE DATABASE TailLog WITH RECOVERY;
GO

-- Is everything there?
SELECT * FROM TailLog..TestTable;
GO

