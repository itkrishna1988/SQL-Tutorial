USE master;
GO

IF DATABASEPROPERTYEX ('TailLogAfterMinLog', 'Version') > 0
	DROP DATABASE TailLogAfterMinLog;
GO

-- Create the database
CREATE DATABASE TailLogAfterMinLog ON PRIMARY (
    NAME = 'TailLogAfterMinLog_data',
    FILENAME = N'D:\PluralSight\TailLogAfterMinLog_data.mdf')
LOG ON (
    NAME = 'TailLogAfterMinLog_log',
    FILENAME = N'D:\PluralSight\TailLogAfterMinLog_log.ldf',
    SIZE = 5MB,
    FILEGROWTH = 1MB);
GO

USE TailLogAfterMinLog;
GO

ALTER DATABASE TailLogAfterMinLog
	SET RECOVERY FULL;
GO

-- Create a table
CREATE TABLE TestTable (
	c1 INT IDENTITY,
	c2 VARCHAR (100));
GO
CREATE CLUSTERED INDEX TestTable_CL
	ON TestTable (c1);
GO

INSERT INTO TestTable
	VALUES ('Initial data: transaction 1');
GO

-- And take a full backup
BACKUP DATABASE TailLogAfterMinLog TO
	DISK = 'D:\PluralSight\TailLogAfterMinLog.bck'
WITH INIT;
GO

-- Now add some more data
SET NOCOUNT ON;
GO
INSERT INTO TestTable
	VALUES ('More data...');
GO 1000

BACKUP LOG TailLogAfterMinLog TO
	DISK = 'D:\PluralSight\TailLogAfterMinLog_Log1.bck'
WITH INIT;
GO

-- Minimally-logged operation
ALTER DATABASE TailLogAfterMinLog
	SET RECOVERY BULK_LOGGED;
GO

ALTER INDEX TestTable_CL ON TestTable REBUILD;
GO

ALTER DATABASE TailLogAfterMinLog
	SET RECOVERY FULL;
GO

-- And some more user transactions
INSERT INTO TestTable
	VALUES ('Transaction 2');
GO
INSERT INTO TestTable
	VALUES ('Transaction 3');
GO

-- Simulate a crash
SHUTDOWN WITH NOWAIT;
GO

-- Trash the data file and restart SQL

USE TailLogAfterMinLog;
GO

-- The backup doesn't have the most recent
-- transactions - if we restore it we'll
-- lose them.

-- Take a log backup!
BACKUP LOG TailLogAfterMinLog TO
	DISK = 'D:\PluralSight\TailLogAfterMinLog_tail.bck'
WITH INIT, NO_TRUNCATE;
GO

-- Hmm - marked as corrupt!

-- Now restore
RESTORE DATABASE TailLogAfterMinLog FROM
	DISK = 'D:\PluralSight\TailLogAfterMinLog.bck'
WITH REPLACE, NORECOVERY;
GO

RESTORE LOG TailLogAfterMinLog FROM
	DISK = 'D:\PluralSight\TailLogAfterMinLog_Log1.bck'
WITH REPLACE, NORECOVERY;
GO

RESTORE LOG TailLogAfterMinLog FROM
	DISK = 'D:\PluralSight\TailLogAfterMinLog_tail.bck'
WITH REPLACE;
GO

-- Force it with CONTINUE_AFTER_ERROR
RESTORE LOG TailLogAfterMinLog FROM
	DISK = 'D:\PluralSight\TailLogAfterMinLog_tail.bck'
WITH REPLACE, CONTINUE_AFTER_ERROR;
GO

-- Hmm - doesn't look good.

-- Is everything there?
SELECT * FROM TailLogAfterMinLog..TestTable;
GO

-- Woah!
DBCC CHECKDB (TailLogAfterMinLog) WITH NO_INFOMSGS;
GO

-- The tail-of-the-log backup is essentially corrupt because
-- it couldn't back up the data file pages

-- Re-restore without the tail-of-the-log
RESTORE DATABASE TailLogAfterMinLog FROM
	DISK = 'D:\PluralSight\TailLogAfterMinLog.bck'
WITH REPLACE, NORECOVERY;
GO

RESTORE LOG TailLogAfterMinLog FROM
	DISK = 'D:\PluralSight\TailLogAfterMinLog_Log1.bck'
WITH REPLACE;
GO

-- Is everything there?
SELECT * FROM TailLogAfterMinLog..TestTable;
GO

-- Nope - lost transaction 2 and 3
