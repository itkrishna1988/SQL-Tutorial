USE master;
GO

IF DATABASEPROPERTYEX ('LogRecords', 'Version') > 0
	DROP DATABASE LogRecords;

CREATE DATABASE LogRecords;
GO

USE LogRecords;
GO
SET NOCOUNT ON;
GO

-- Make sure the database is in SIMPLE
-- recovery model with no auto-stats (to avoid
-- unwanted log records)
ALTER DATABASE LogRecords SET RECOVERY SIMPLE;
ALTER DATABASE LogRecords SET AUTO_CREATE_STATISTICS OFF;
GO

-- Create a simple table to play with
CREATE TABLE Test (
	c1 INT,
	c2 INT,
	c3 INT);
GO

-- Insert a record to get the allocations done
INSERT INTO Test VALUES (1, 1, 1);
GO

-- Clear out the log
CHECKPOINT;
GO

-- Look in the log
SELECT * FROM fn_dblog (NULL, NULL);
GO

-- Implicit transaction to insert a new record
INSERT INTO Test VALUES (2, 2, 2);
GO

-- Look at various fields, including locks being logged
SELECT * FROM fn_dblog (NULL, NULL);
GO

-- Explicit transaction to insert a new record
BEGIN TRAN;
GO
INSERT INTO Test VALUES (3, 3, 3);
GO

-- Now roll it back
ROLLBACK TRAN;
GO

-- Look for COMPENSATION context
SELECT * FROM fn_dblog (NULL, NULL);
GO

-- clear things out again
CHECKPOINT;
GO

-- Update a column
BEGIN TRAN;
GO
UPDATE Test SET c1 = 4 WHERE c1 = 1;
GO

-- Look for before and after
SELECT * FROM fn_dblog (NULL, NULL);
GO

-- Now roll it back
ROLLBACK TRAN;
GO

-- Look for before and after
SELECT * FROM fn_dblog (NULL, NULL);
GO

-- More complex analysis
SELECT
	SUM ([Log Record Length])
FROM fn_dblog (NULL, NULL)
WHERE
	[Transaction ID] = '';
GO

