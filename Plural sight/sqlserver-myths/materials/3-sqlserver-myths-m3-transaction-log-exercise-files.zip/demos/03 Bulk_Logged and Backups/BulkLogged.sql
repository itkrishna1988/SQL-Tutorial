USE master;
GO

IF DATABASEPROPERTYEX ('BulkLogged', 'Version') > 0
	DROP DATABASE BulkLogged;
GO

-- Create the database
CREATE DATABASE BulkLogged;
GO

USE BulkLogged;
GO

-- Create a table and insert 8MB
CREATE TABLE Test (
	c1 INT IDENTITY,
	c2 CHAR (8000) DEFAULT 'a');
GO
CREATE CLUSTERED INDEX Test_CL ON Test (c1);
GO

SET NOCOUNT ON;
GO

INSERT INTO Test DEFAULT VALUES;
GO 1000

-- Put the database into the FULL recovery
-- model and clear out the log.
ALTER DATABASE BulkLogged SET RECOVERY FULL;
GO

BACKUP DATABASE BulkLogged TO
	DISK = 'D:\PluralSight\BulkLogged_Full_0.bak'
	WITH INIT, STATS;
GO

BACKUP LOG BulkLogged TO
	DISK = 'D:\PluralSight\BulkLogged_Log_0_Initial.bak'
	WITH INIT, STATS;
GO

-- Now rebuild the clustered index to
-- generate a bunch of log
ALTER INDEX Test_CL ON Test REBUILD;
GO

-- Backup the log to get a baseline size
BACKUP LOG BulkLogged TO
	DISK = 'D:\PluralSight\BulkLogged_Log_1_Baseline.bak'
	WITH INIT, STATS;
GO

-- Now let's try a rebuild in BULK_LOGGED
-- recovery model. Does that change log
-- backup size?
ALTER DATABASE BulkLogged
	SET RECOVERY BULK_LOGGED;
GO

ALTER INDEX Test_CL ON Test REBUILD;
GO

BACKUP LOG BulkLogged TO
	DISK = 'D:\PluralSight\BulkLogged_Log_2_BulkTest.bak'
	WITH INIT, STATS;
GO