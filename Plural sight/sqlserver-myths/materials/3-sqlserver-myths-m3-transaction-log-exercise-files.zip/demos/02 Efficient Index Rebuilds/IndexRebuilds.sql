USE master;
GO

IF DATABASEPROPERTYEX ('IndexRebuilds', 'Version') > 0
	DROP DATABASE IndexRebuilds;
GO

-- Create the database
CREATE DATABASE IndexRebuilds;
GO

USE IndexRebuilds;
GO
SET NOCOUNT ON;
GO

-- Create the test table
CREATE TABLE Test (
	c1 INT IDENTITY,
	c3 CHAR (1000) DEFAULT 'a');
GO
CREATE CLUSTERED INDEX Test_CL ON Test (c1);
GO
INSERT INTO Test DEFAULT VALUES;
GO 10000

-- Clear the log
CHECKPOINT;
GO

-- Switch to the Full recovery model
ALTER DATABASE IndexRebuilds SET RECOVERY FULL;
GO

BACKUP DATABASE IndexRebuilds TO
	DISK = 'D:\PluralSight\IndexRebuilds_Full.bak'
	WITH INIT, STATS;
GO

-- Rebuild the index
ALTER INDEX Test_CL ON Test REBUILD;
GO

-- Examine the log
SELECT * FROM fn_dblog (NULL, NULL);
GO
