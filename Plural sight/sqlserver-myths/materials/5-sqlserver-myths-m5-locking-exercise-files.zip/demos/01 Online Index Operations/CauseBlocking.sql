USE OnlineIndexLocks;
GO

BEGIN TRAN;
GO

UPDATE
	Test
SET
	[C2] = 4
WHERE
	[c1] = 453;
GO

-- Run to here

COMMIT TRAN;
GO
