USE master;
GO

IF DATABASEPROPERTYEX ('OnlineIndexLocks', 'Version') > 0
	DROP DATABASE OnlineIndexLocks;
GO

-- Create the database
CREATE DATABASE OnlineIndexLocks;
GO

USE OnlineIndexLocks;
GO
SET NOCOUNT ON;
GO

-- Create the test table
CREATE TABLE Test (
	c1 INT IDENTITY,
	c2 BIGINT DEFAULT 1,
	c3 CHAR (8000) DEFAULT 'a');
GO
CREATE CLUSTERED INDEX Test_CL ON Test (c1);
GO
INSERT INTO Test DEFAULT VALUES;
GO 10000 

-- Online index rebuild
ALTER INDEX Test_CL ON Test REBUILD
WITH (ONLINE = ON);
GO

-- Now run CauseBlocking.sql

-- Examine the locks

-- Try the online index rebuild again
ALTER INDEX Test_CL ON Test REBUILD
WITH (ONLINE = ON);
GO

-- Examine the locks
