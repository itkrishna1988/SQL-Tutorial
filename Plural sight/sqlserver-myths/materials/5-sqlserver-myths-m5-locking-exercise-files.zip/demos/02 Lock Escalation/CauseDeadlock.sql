-- Cause escalation to another partition X lock by
-- updating all rows from partition 2 in a single
-- transaction
USE LockEscalationTest;
GO

BEGIN TRAN
UPDATE MyPartitionedTable set c1 = c1
	WHERE c1 > 8000 AND c1 < 16000;
GO

-- Check the locks being held...

-- Use this to cause a deadlock
-- Selects a row from partition 1 while that partition
-- is X locked
SELECT * FROM MyPartitionedTable WHERE c1 = 100;
GO

-- Execute to here

ROLLBACK TRAN;
GO

