-- Simple select against partition 3
USE LockEscalationTest;
GO

-- This will fail if table-level lock escalation has
-- taken place
SELECT COUNT (*) FROM MyPartitionedTable
	WHERE c1 >= 16000;
GO

-- Check the locks being held...

ROLLBACK TRAN;
GO
