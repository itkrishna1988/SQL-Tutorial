-- Check the locks being held
USE LockEscalationTest;
GO

SELECT * FROM sys.partitions WHERE object_id =
	OBJECT_ID ('MyPartitionedTable');
GO

SELECT
	[resource_type],
	[resource_subtype],
	[resource_description],
	[resource_associated_entity_id],
	[request_mode],
	[request_status],
	[request_session_id]
FROM
	sys.dm_tran_locks
WHERE
	[resource_type] <> 'DATABASE';
GO


