/*
Download the SalesDB database zip file, unzip it and restore it.
Get it from:
https://s3.amazonaws.com/pluralsight-mediasource/sqlskills/SalesDBOriginal.zip

Here's an example of restoring it:

RESTORE DATABASE SalesDB
	FROM DISK = N'D:\PluralSight\SalesDBOriginal.bak'
	WITH MOVE N'SalesDBData' TO N'D:\PluralSight\SalesDBData.mdf',
	MOVE N'SalesDBLog' TO N'D:\PluralSight\SalesDBLog.ldf',
	REPLACE, STATS = 10;
GO
*/

USE master;
GO

-- Drop everything from the buffer pool
DBCC DROPCLEANBUFFERS;
GO

-- Get rid of any snapshot that may exist and prevent a restore
IF DATABASEPROPERTYEX ('SalesDB_Snapshot', 'Version') > 0
	DROP DATABASE SalesDB_Snapshot;
GO

-- Create the snapshot
CREATE DATABASE SalesDB_Snapshot
ON (NAME = N'SalesDBData',
	FILENAME = N'D:\PluralSight\SalesDBData.mdfss')
AS SNAPSHOT OF SalesDB;
GO

-- Show size on disk of snapshot
SELECT
	vfs.[file_id] AS [File ID],
	mf.[name] AS [Filename],
	vfs.[size_on_disk_bytes] / 1024 AS [Sparse File PHYSICAL Size (KB)]
FROM
	sys.dm_io_virtual_file_stats (NULL, NULL) AS vfs
JOIN
	sys.master_files AS mf
ON
	vfs.[file_id] = mf.[file_id]
WHERE
	mf.[database_id] = vfs.[database_id]
	AND mf.[database_id] = DB_ID ('SalesDB_Snapshot');
GO

-- Now let's look at size in memory
SELECT *,
	[DirtyPageCount] * 8 / 1024 AS [DirtyPageMB],
	[CleanPageCount] * 8 / 1024 AS [CleanPageMB]
FROM
	(SELECT 
		(CASE WHEN ([database_id] = 32767)
			THEN 'Resource Database'
			ELSE DB_NAME ([database_id]) END) AS [DatabaseName], 
		SUM (CASE WHEN ([is_modified] = 1)
			THEN 1 ELSE 0 END) AS [DirtyPageCount], 
		SUM (CASE WHEN ([is_modified] = 1)
			THEN 0 ELSE 1 END) AS [CleanPageCount]
	FROM sys.dm_os_buffer_descriptors
	GROUP BY [database_id]) AS buffers
ORDER BY [DatabaseName]
GO 

-- Now some queries
SELECT
	COUNT (*)
FROM
	SalesDB.dbo.Sales;
GO

SELECT
	COUNT (*)
FROM
	SalesDB_Snapshot.dbo.Sales;
GO

-- And check size again
SELECT *,
	[DirtyPageCount] * 8 / 1024 AS [DirtyPageMB],
	[CleanPageCount] * 8 / 1024 AS [CleanPageMB]
FROM
	(SELECT 
		(CASE WHEN ([database_id] = 32767)
			THEN 'Resource Database'
			ELSE DB_NAME ([database_id]) END) AS [DatabaseName], 
		SUM (CASE WHEN ([is_modified] = 1)
			THEN 1 ELSE 0 END) AS [DirtyPageCount], 
		SUM (CASE WHEN ([is_modified] = 1)
			THEN 0 ELSE 1 END) AS [CleanPageCount]
	FROM sys.dm_os_buffer_descriptors
	GROUP BY [database_id]) AS buffers
ORDER BY [DatabaseName]
GO 

-- Woah! No changes to the snapshot and yet
-- it's taking up memory?

-- Or is it?
USE SalesDB;
GO

DBCC IND (SalesDB, Sales, -1);
GO

DBCC TRACEON (3604);

DBCC PAGE (SalesDB, 1, XX, 2);

-- In other window (for easy comparison)
DBCC TRACEON (3604);

DBCC PAGE (SalesDB_Snapshot, 1, XX, 2);
GO

-- Look at the BUF addresses 
