USE MASTER
GO
IF DATABASEPROPERTYEX ('DemoFilegroups1', 'Version') > 0
	DROP DATABASE DemoFilegroups1;
GO
IF DATABASEPROPERTYEX ('DemoFilegroups2', 'Version') > 0
	DROP DATABASE DemoFilegroups2;
GO

-- Create database with 3 filegroups
CREATE DATABASE DemoFilegroups1
ON (NAME = DemoFilegroups1_Data,
    FILENAME = N'D:\PluralSight\DemoFilegroups1_Data.mdf')
LOG ON (NAME = DemoFilegroups1_Log,
    FILENAME = N'D:\PluralSight\DemoFilegroups1_log.ldf');
GO

ALTER DATABASE DemoFilegroups1
	ADD FILEGROUP DFG1_Filegroup1;
GO
ALTER DATABASE DemoFilegroups1
	ADD FILEGROUP DFG1_Filegroup2;
GO

ALTER DATABASE DemoFilegroups1
ADD FILE
	(NAME = DFG1_TestFile1,
	FILENAME = N'D:\PluralSight\DFG1_TestFile1.ndf')
TO FILEGROUP DFG1_Filegroup1;
GO
ALTER DATABASE DemoFilegroups1
ADD FILE
	(NAME = DFG1_TestFile2,
	FILENAME = N'D:\PluralSight\DFG1_TestFile2.ndf')
TO FILEGROUP DFG1_Filegroup2;
GO

-- Create another database with 3 filegroups
CREATE DATABASE DemoFilegroups2
ON (NAME = DemoFilegroups2_Data,
    FILENAME = N'D:\PluralSight\DemoFilegroups2_Data.mdf')
LOG ON (NAME = DemoFilegroups2_Log,
    FILENAME = N'D:\PluralSight\DemoFilegroups2_log.ldf');
GO

ALTER DATABASE DemoFilegroups2
	ADD FILEGROUP DFG2_Filegroup1;
GO
ALTER DATABASE DemoFilegroups2
	ADD FILEGROUP DFG2_Filegroup2;
GO

ALTER DATABASE DemoFilegroups2
ADD FILE
	(NAME = DFG2_TestFile1,
	FILENAME = N'D:\PluralSight\DFG2_TestFile1.ndf')
TO FILEGROUP DFG2_Filegroup1;
GO
ALTER DATABASE DemoFilegroups2
ADD FILE
	(NAME = DFG2_TestFile2,
	FILENAME = N'D:\PluralSight\DFG2_TestFile2.ndf')
TO FILEGROUP DFG2_Filegroup2;
GO

-- Take full database backups
BACKUP DATABASE DemoFilegroups1
TO DISK = N'D:\PluralSight\Filegroups1.bak'
WITH INIT;
GO

BACKUP DATABASE DemoFilegroups2
TO DISK = N'D:\PluralSight\Filegroups2.bak'
WITH INIT;
GO

-- Now drop both databases
DROP DATABASE DemoFilegroups1;
DROP DATABASE DemoFilegroups2;
GO

-- Partial restore of DemoFilegroups1
RESTORE DATABASE DemoFilegroups1
    FILEGROUP = 'PRIMARY'
FROM DISK = N'D:\PluralSight\Filegroups1.bak'
WITH PARTIAL, STATS;
GO

-- Check filegroup status
SELECT
	[name],
	[state_desc]
FROM
	DemoFilegroups1.sys.database_files;
GO

-- Restore another filegroup
RESTORE DATABASE DemoFilegroups1
    FILEGROUP = 'DFG1_Filegroup1'
FROM DISK = N'D:\PluralSight\Filegroups1.bak'
WITH STATS;
GO

-- Now try one from another database
RESTORE DATABASE DemoFilegroups1
    FILEGROUP = 'DFG2_Filegroup2'
FROM DISK = N'D:\PluralSight\Filegroups2.bak'
WITH STATS;
GO