USE master;
GO
IF DATABASEPROPERTYEX ('Downlevel', 'Version') > 0
	DROP DATABASE Downlevel;
GO

-- Create database
CREATE DATABASE Downlevel
ON (NAME = Downlevel_Data,
    FILENAME = N'D:\PluralSight\Downlevel_data.mdf')
LOG ON (NAME = Downlevel_Log,
    FILENAME = N'D:\PluralSight\Downlevel_log.ldf');
GO

-- Take full database backup
BACKUP DATABASE Downlevel
TO DISK = N'D:\PluralSight\Downlevel.bak'
WITH INIT;
GO

-- Connect to 2008R2 instance
RESTORE DATABASE Downlevel2
FROM DISK = N'D:\PluralSight\Downlevel.bak'
	WITH MOVE N'Downlevel_Data' TO N'D:\PluralSight\Downlevel_data2.mdf',
	MOVE N'Downlevel_Log' TO N'D:\PluralSight\Downlevel_log2.ldf',
	REPLACE, STATS = 10;
GO