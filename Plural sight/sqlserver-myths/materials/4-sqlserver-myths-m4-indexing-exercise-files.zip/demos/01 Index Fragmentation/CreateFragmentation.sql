USE master;
GO

IF DATABASEPROPERTYEX ('GUIDTest', 'Version') > 0
	DROP DATABASE GUIDTest;

CREATE DATABASE GUIDTest ON PRIMARY (
    NAME = 'GUIDTest_data',
    FILENAME = N'D:\SQLskills\GUIDTest_data.mdf',
    SIZE = 400MB,
    FILEGROWTH = 25MB)
LOG ON (
    NAME = 'GUIDTest_log',
    FILENAME = N'D:\SQLskills\GUIDTest_log.ldf',
    SIZE = 100MB,
    FILEGROWTH = 5MB);
GO

ALTER DATABASE GUIDTest SET RECOVERY SIMPLE;
GO

USE GUIDTest;
GO

SET NOCOUNT ON;
GO

-- Create a table with a GUID key
CREATE TABLE BadKeyTable (
	c1 UNIQUEIDENTIFIER DEFAULT NEWID () ROWGUIDCOL,
    c2 DATETIME DEFAULT GETDATE (),
	c3 CHAR (400) DEFAULT 'a',
	c4 VARCHAR(MAX) DEFAULT 'b');
CREATE CLUSTERED INDEX BadKeyTable_CL ON
	BadKeyTable (c1);
CREATE NONCLUSTERED INDEX BadKeyTable_NCL ON
	BadKeyTable (c2);
GO

-- Create another one, but using
-- NEWSEQUENTIALID instead
CREATE TABLE BadKeyTable2 (
	c1 UNIQUEIDENTIFIER DEFAULT NEWSEQUENTIALID () ROWGUIDCOL,
    c2 DATETIME DEFAULT GETDATE (),
	c3 CHAR (400) DEFAULT 'a',
	c4 VARCHAR(MAX) DEFAULT 'b');
CREATE CLUSTERED INDEX BadKeyTable2_CL ON
	BadKeyTable2 (c1);
CREATE NONCLUSTERED INDEX BadKeyTable2_NCL ON
	BadKeyTable2 (c2);
GO

-- Create some fragmentation
DECLARE @a INT;
SELECT @a = 1;
WHILE (@a < 250000)
BEGIN
	INSERT INTO BadKeyTable DEFAULT VALUES;
	INSERT INTO BadKeyTable2 DEFAULT VALUES;
	SELECT @a = @a + 1;
END;
GO

-- Examine fragmentation
SELECT
	OBJECT_NAME (ips.[object_id]) AS 'Object Name',
	si.name AS 'Index Name',
	ROUND (ips.avg_fragmentation_in_percent, 2) AS 'Fragmentation',
	ips.page_count AS 'Pages',
	ROUND (ips.avg_page_space_used_in_percent, 2) AS 'Page Density'
FROM sys.dm_db_index_physical_stats (
	DB_ID ('GUIDTest'),
	NULL,
	NULL,
	NULL,
	'DETAILED') ips
CROSS APPLY sys.indexes si
WHERE
	si.object_id = ips.object_id
	AND si.index_id = ips.index_id
	AND ips.index_level = 0
GO
