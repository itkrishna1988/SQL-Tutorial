/*
Download the SalesDB database zip file, unzip it and restore it.
Get it from:
https://s3.amazonaws.com/pluralsight-mediasource/sqlskills/SalesDBOriginal.zip

Here's an example of restoring it:

RESTORE DATABASE SalesDB
	FROM DISK = N'D:\PluralSight\SalesDBOriginal.bak'
	WITH MOVE N'SalesDBData' TO N'D:\PluralSight\SalesDBData.mdf',
	MOVE N'SalesDBLog' TO N'D:\PluralSight\SalesDBLog.ldf',
	REPLACE, STATS = 10;
GO
*/

USE master;
GO

-- Make sure we have the SalesDB database

-- Run Step 1 of the CreateTransaction.sql script

-- Flush out the error log
EXEC sp_cycle_errorlog;
GO

-- Run DBCC CHECKDB
DBCC CHECKDB ('SalesDB') WITH NO_INFOMSGS;
GO

-- Examine the error log
EXEC xp_readerrorlog;
GO

-- Run Step 2 of the CreateTransaction.sql script