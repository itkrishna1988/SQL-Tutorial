-- Step 1
BEGIN TRANSACTION;
GO

UPDATE SalesDB.dbo.Sales
SET Quantity = 1
WHERE SalesID < 1000;
GO

-- Execute to here


-- Step 2
ROLLBACK TRANSACTION;
GO
