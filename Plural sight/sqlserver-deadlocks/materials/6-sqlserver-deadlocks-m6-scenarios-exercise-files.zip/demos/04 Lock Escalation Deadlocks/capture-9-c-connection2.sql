USE [DeadlockDemo];
GO 

BEGIN TRANSACTION

UPDATE [EscalationDeadlock]
SET [c1] = [c1] 
WHERE [c1] > 8100 
  AND [c1] < 15900;


-- Trigger deadlock on escalation
SELECT * 
FROM [EscalationDeadlock]
WHERE [c1] = 100;
GO 
