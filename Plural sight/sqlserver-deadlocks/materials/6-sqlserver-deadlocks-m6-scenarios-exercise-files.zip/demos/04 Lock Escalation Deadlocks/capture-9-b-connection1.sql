USE [DeadlockDemo];
GO
BEGIN TRANSACTION

UPDATE EscalationDeadlock 
SET [c1] = [c1] 
WHERE [c1] < 7500;

-- Change windows to run second update

-- Force deadlock
SELECT * 
FROM [EscalationDeadlock]
WHERE [c1] = 8500;
GO 
