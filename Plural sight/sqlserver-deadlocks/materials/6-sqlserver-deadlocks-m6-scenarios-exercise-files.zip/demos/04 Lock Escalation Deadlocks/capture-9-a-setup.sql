USE [DeadlockDemo];
GO 

-- Drop objects if they already exist
IF OBJECT_ID(N'EscalationDeadlock') IS NOT NULL
	DROP TABLE [EscalationDeadlock];
IF OBJECT_ID(N'ps_EscalationDeadlock') IS NOT NULL
	DROP PARTITION SCHEME [ps_EscalationDeadlock];
IF OBJECT_ID(N'pf_EscalationDeadlock') IS NOT NULL
	DROP PARTITION FUNCTION [pf_EscalationDeadlock];
GO

-- Create a partition function with three partitions: -7999, 8000-15999, 16000+
CREATE PARTITION FUNCTION [pf_EscalationDeadlock] (INT) 
AS RANGE RIGHT FOR VALUES (8000, 16000);
GO 

-- Create the partition scheme
CREATE PARTITION SCHEME [ps_EscalationDeadlock] 
AS PARTITION [pf_EscalationDeadlock]
ALL TO ([PRIMARY]);
GO 

-- Create a partitioned table
CREATE TABLE [EscalationDeadlock] ([c1] INT);
GO 

CREATE CLUSTERED INDEX [cix_EscalationDeadlock]
ON [EscalationDeadlock] ([c1])
ON [ps_EscalationDeadlock] ([c1]);
GO 

-- Populate the table with data
SET NOCOUNT ON;
GO 

DECLARE @a INT = 1;
WHILE (@a < 17000)
BEGIN
	INSERT INTO [EscalationDeadlock] 
		([c1])
	VALUES (@a);

	SELECT @a = @a + 1;
END;
GO 

-- Change lock escalation to allow partition level
ALTER TABLE [EscalationDeadlock] 
SET (LOCK_ESCALATION = AUTO);
GO 

