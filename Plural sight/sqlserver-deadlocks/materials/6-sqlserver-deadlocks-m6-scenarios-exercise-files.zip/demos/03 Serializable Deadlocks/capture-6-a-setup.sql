USE [AdventureWorks2012];
GO

-- Drop the procedure if it exists
IF OBJECT_ID(N'SerializableDeadlock') IS NOT NULL
	DROP PROCEDURE [SerializableDeadlock];
GO

-- Create a serializable process stored procedure to trigger deadlocks
CREATE PROCEDURE [SerializableDeadlock] 
( @NewSales XML )
AS
SET NOCOUNT ON

-- Change to serializable isolation
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE

-- Begin a transaction
BEGIN TRANSACTION

-- Perform existence check to acquire shared range shared locks
IF NOT EXISTS ( SELECT *
				FROM Sales.SalesOrderHeader
				WHERE CustomerID = 105)
BEGIN

	-- Perform insert to convert to shared range insert locks
	INSERT INTO [Sales].[SalesOrderHeader]
           ([RevisionNumber], [OrderDate], [DueDate], [ShipDate], [Status], 
			[OnlineOrderFlag], [PurchaseOrderNumber], [AccountNumber], [CustomerID], 
			[SalesPersonID], [TerritoryID], [BillToAddressID], [ShipToAddressID],
			[ShipMethodID], [CreditCardID], [CreditCardApprovalCode], [CurrencyRateID],
			[SubTotal], [TaxAmt], [Freight], [Comment])
	SELECT
		n.value('(RevisionNumber)[1]', 'int'),
		n.value('(OrderDate)[1]', 'datetime'),
		n.value('(DueDate)[1]', 'datetime'),
		n.value('(ShipDate)[1]', 'datetime'),
		n.value('(Status)[1]', 'tinyint'),
		n.value('(OnlineOrderFlag)[1]', 'bit'),
		n.value('(PurchaseOrderNumber)[1]', 'nvarchar(25)'),
		n.value('(AccountNumber)[1]', 'nvarchar(15)'),
		n.value('(CustomerID)[1]', 'nvarchar(15)'),
		n.value('(SalesPersonID)[1]', 'int'),
		n.value('(TerritoryID)[1]', 'int'),
		n.value('(BillToAddressID)[1]', 'int'),
		n.value('(ShipToAddressID)[1]', 'int'),
		n.value('(ShipMethodID)[1]', 'int'),
		n.value('(CreditCardID)[1]', 'int'),
		n.value('(CreditCardApprovalCode)[1]', 'varchar(15)'),
		n.value('(CurrencyRateID)[1]', 'int'),
		n.value('(SubTotal)[1]', 'money'),
		n.value('(TaxAmt)[1]', 'money'),
		n.value('(Freight)[1]', 'money'),
		n.value('(Comment)[1]', 'nvarchar(128)')
	FROM @NewSales.nodes('SalesOrders/SalesOrderHeader') q(n)

END

-- Rollback the transaction to make it possible to repeat until we deadlock
ROLLBACK

GO