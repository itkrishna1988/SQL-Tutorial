USE [DeadlockDemo];
GO
SELECT * 
FROM sys.indexes 
WHERE object_id = object_id(N'TableA');